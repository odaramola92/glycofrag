"""Tests for glycofrag package."""
